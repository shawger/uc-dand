## References:

sklearn - http://scikit-learn.org/stable/index.html - Main reference for using sklearn.